(function($){
	"use strict"

	$('#footable').footable();
	
})(jQuery);